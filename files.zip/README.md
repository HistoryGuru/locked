# StudyFlow

An AI-powered study suite with a persistent Pomodoro timer and smart question generation, powered by Grok (xAI).

## Features

- **Study Timer** — Pomodoro, 52/17, Ultradian 90-min, or custom modes. Runs in the background across tab switches, updates the page title with the live countdown, and sends desktop notifications when sessions end.
- **Question Generator** — Generate practice questions from a topic or uploaded file. Supports multiple choice (interactive), true/false (interactive), short answer, essay, and fill-in-the-blank.
- **Learn More** — When using a file, click "Learn More" on any question for a deeper AI explanation pointing back to the source text.
- **Draggable floating timer** — Stays visible while studying in the Questions tab.

---

## Running Locally

### 1. Install dependencies
```bash
npm install
```

### 2. Start the server
```bash
npm start
```

### 3. Open in browser
```
http://localhost:3001
```

---

## Deploying Free to Railway

1. Push this repo to GitHub
2. Go to railway.app → New Project → Deploy from GitHub repo
3. Select your repo — Railway auto-detects Node.js and runs `npm start`
4. Go to Settings → Networking → Generate Domain for a public URL

---

## Deploying Free to Render

1. Push to GitHub
2. Go to render.com → New → Web Service → connect your repo
3. Build command: `npm install` | Start command: `node server.js`
4. Deploy — get a free *.onrender.com URL

---

## Project Structure

```
studyflow/
├── index.html    # Full frontend
├── server.js     # Node proxy server
├── package.json
├── .gitignore
└── README.md
```
