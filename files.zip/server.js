const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;
const GROK_API_KEY = process.env.GROK_API_KEY || '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';

app.use(express.json({ limit: '2mb' }));

// Serve the frontend
app.use(express.static(path.join(__dirname)));

// Proxy endpoint for Grok API
app.post('/api/grok', async (req, res) => {
  try {
    const response = await fetch('https://api.x.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GROK_API_KEY}`,
      },
      body: JSON.stringify(req.body),
    });

    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    res.status(500).json({ error: { message: err.message } });
  }
});

app.listen(PORT, () => {
  console.log(`\n✦ StudyFlow running at http://localhost:${PORT}\n`);
});
